import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.page.html',
  styleUrls: ['./add-tutorial.page.scss'],
})
export class AddTutorialPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
