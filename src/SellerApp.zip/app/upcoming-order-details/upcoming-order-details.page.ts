import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-order-details',
  templateUrl: './upcoming-order-details.page.html',
  styleUrls: ['./upcoming-order-details.page.scss'],
})
export class UpcomingOrderDetailsPage implements OnInit {
	profile: string = "posts";
  constructor() { }

  ngOnInit() {
  }

}
